﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.Mail;


namespace HelloWorldApp
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string str = "Hello world";
            char tecken = 'o';


            //Console.WriteLine(ContainsChar(str, tecken));
            //Console.WriteLine(IndexOfChar(str, tecken));

            //Console.WriteLine(Reverse(str));

            int[] arr = new int[] { 1, 7, 1, 0, 5, 0, 5 };
            int element = 1;

            //Console.WriteLine(ContainsElement(arr, element));
            List<int> unique = Unique(arr);

        }
        public static List<int> Unique(int[] input)
        {
            List<int> output = new List<int>();
            foreach (int element in input)
            {
                bool finnsRedan = false;
                foreach (int uniktElement in output)
                {
                    if(uniktElement == element)
                    {
                        finnsRedan = true;
                        break;
                    }
                }
                if (!finnsRedan)
                {
                    output.Add(element);
                }

            }
            return output;
        }

        public static decimal Mean(List<int> talen)
        {
            decimal output = 0;

            foreach (int tal in talen)
            {
                output += tal;
            }
            output /= talen.Count;
            return output;
        }
        
        public static bool ContainsElement(List<int> list, int element)
        {
            bool output = false;

            foreach (int elementet in list)
            {
                if(elementet == element)
                {
                    output = true;
                    break;
                }
            }

            return output;

        }

        private static bool ContainsChar(string input, char tecken)
        {
            bool output = false;
            foreach (char bokstav in input)
            {
                if(bokstav == tecken)
                {
                    output = true;
                    break;
                }
            }
            return output;
        }

        private static int IndexOfChar(string input, char tecken)
        {
            int output = -1;
            for (int i = 0; i < input.Length; i++)
            {
                char bokstav = input[i];
                if(bokstav == tecken)
                {
                    output = i;
                    break;
                }
            }

            return output;
        }

        private static string Reverse(string input)
        {
            string output = "";
            for (int i = input.Length - 1; i >= 0; i--)
            {
                char bokstav = input[i];
                output =output + bokstav;   
            }

            return output;
        }
    }

    
}
