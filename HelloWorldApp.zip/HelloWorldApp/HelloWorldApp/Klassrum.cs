﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorldApp
{
    class Klassrum
    {
        public List<Person> Studenter { get; set; } = new List<Person>();
    }
}
